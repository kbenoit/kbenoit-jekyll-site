Hungarian Local Election Data Guide
Kenneth Benoit
1997

Extensions:  .xls original excel file
~~~~~~~~~~   .asc text file for input to ATOG
	     .dat Gauss data file
	     .atg Gauss ATOG command file


========================================================================
GUIDE TO INPUT DATASETS
=======================

loc94may -- data for 1994 mayoral elections
~~~~~~~~
      maysetc,    @ settlement code @
      maypcod,    @ party code @
      mayvote;    @ valid votes @

loc94may.xls
Contents: Mayoral Elections 1994

T_TAZ	  Settlement code
nevdr	  Space for "Dr."
nev	  Candidate name
T_SZKOD   party code
T_SZAV	  valid votes

------------------------------------------------------------

loc94org -- data for 1994 parties and coalitions
~~~~~~~~
      pcode,      @ party code @
      pcoalno,    @ valid votes @
      coal1,      @ surplus vote recipient @
      coal2,      @ surplus vote recipient @
      coal3,      @ surplus vote recipient @
      coal4,      @ surplus vote recipient @
      coal5,      @ surplus vote recipient @
      coal6,      @ surplus vote recipient @
      coal7,      @ surplus vote recipient @
      coal8,      @ surplus vote recipient @
      coal9;      @ surplus vote recipient @

loc94org.xls
Contents: Parties and alliances in local elections

SZ_KOD	  party code
SZ_NEVT   Party name
SZ_TSZAM  number of parties in coalition

------------------------------------------------------------

loc94smd -- data for the >10,000 SMD contests in 1994 local elections
~~~~~~~~
      smdsetc,    settlement code
      smdno,      SMD number within settlement
      smdpcod,    party code of candidate
      smdvote;    votes received

loc94smd.xls
Contents: SMD candidates for local election SMDs in > 10,000 towns

E_TAZ	  Settlement code
E_TEVK	  SMD number within settlement
nevdr	  Space for "Dr."
nev	  Candidate name
E_SZKOD	  Party code
E_SZAV	  Valid votes

------------------------------------------------------------

loc94man -- data for 1994 settlements (names and mandates)
~~~~~~~~
      setcode,    @ settlement code @
      setpop,     @ settlement population  @
      setsmds,    @ # of seats distributable in SMDs in settlement @
      setlist;    @ # of seats distributable from settlement list @

loc94man.xls
Contents: Distributable Mandates - 1994 Local Elections

T_TAZ	  Settlement code
T_NEV	  Settlement name
T_LAKOS	  Population
T_TEGY	  Distributable mandates in SMDs
T_TLIST	  Distributable mandates in list

------------------------------------------------------------

loc94cty -- county/municipal assembly elections 1994
~~~~~~~~
      ctycode     county code (1-20)
      ctyltype    1 = <10,000, 2 = >10,000, 3 = Budapest
      ctypcode	  party code
      ctyvote	  valid votes for this party
      ctystwon	  seats won by this party

loc94cty.xls
Contents: Provincial (County) council elections 1994

M_AZ	  county code
M_R_NEV	  county name
M_TIP	  type of list: 1 10e alatt, 2 10e felett, 3 fo''va'ros
M_E	  registered voters at close
M_F	  registered (tallied) voters
  Expr1	  total votes
M_I	  valid votes
M_H	  invalid votes
M_LKOD	  list code
M_SZKOD	  party code
SZ_NEVT	  party list or name
M_SZAV	  valid votes for party
M_MNYERT  mandates won by party

Notes: some problems when the hypothetical counties were run using LR
methods.  Problem is that threshold prevents some parties from
receiving quota-awarded seats, and then there are more remainder seats
to be allocated than there are eligible parties in the remainder
allocation.  In this case the seats are simply unawarded.

LR-Hare:     
  Budapest (1): only 63 of 66 seats awarded.
  Pest (14): large settl. lists, only 41 of 42 seats awarded.
  Vas (18): small settl. lists, only 27 of 29 seats awarded.
  Zala (20): small settl. lists, only 34 of 35 seats awarded.
LR-Droop:     
  Budapest (1): only 65 of 66 seats awarded.
LR-Imperiali: 
  Vas (18) small settl. lists, only 28 of 29 seats awarded.


------------------------------------------------------------

loc94kis -- settlement <10,000 elections (small/kis list)
~~~~~~~~
      kissetc    settlement code
      kispcode   party code
      kisvotes   votes for this party

loc94kis.xls
Contents: Small list elections in < 10,000 towns

T_TAZ     settlement code
NEVDR	  space for Dr. in name
NEV	  name
T_SZKOD	  party code
T_SZAV	  votes

------------------------------------------------------------

loc94com -- settlement >10,000 list elections (compensation list)
~~~~~~~~
invar comsetc     settlement code ( >10,000 inhabitants)
      compcode    compensation list party code
      comvote     valid votes for this party 
      comstwon    seats won by this party

loc94com.xls
Contents: Compensation list elections in towns > 10,000 

T_TAZ     settlement code
T_LKOD	  list code
T_SZKOD	  party code
SZ_NEVT   party name
T_SZAV	  votes
T_MNYERT  mandates won


Notes:
~~~~~
The recreation of awards using the Hungarian Sainte-Lague didn't
always exactly match the actual awards.  This is because the
calculations of averages in practice rounds down to the nearest
integer, sometimes resulting in ties for the last seat to be awarded.

Examples:  

Settlement 1019:
      SZDSZ's potential 4th seat  (3,657 / 7 = 522.4) and
      NAGYCSALAD... pot. 1st seat (783 / 1.5 = 522.0)
In this case the seat goes to the smaller party since the SZDSZ has
already won 3 seats and the smaller party none. 

Settlement 17099:
why do 2 independent candidates receive mandates?



------------------------------------------------------------

loc94par.xls -- parties and coalitions in settlement elections
~~~~~~~~~~~~

loc94par.xls
Contents: coalitions and parties in settlement elections
(one row for each party in an alliance, so number of rows per
party/alliance varies.)

SZ_KOD             party or alliance code
SZERVEZET1_SZ_NEVT Party/alliance name
CS_PAZ             party number of alliance partner
SZERVEZET1_SZ_NEVT Party name of alliance partner


====================================================================
OUPUT DATASETS:
==============

finmayor -- Final 16-column dataset of mayoral election results
~~~~~~~~    [created by mkdstmay.prg]

finsmd --   Final 16-col. dataset of SMD election results in cities
~~~~~~      with more than 10,000 inhabitants
	    [created by mkdstsmd.prg]


====================================================================
Code:
====

mkdstcty.prg   Create the dataset for county elections
mkdstmay.prg   Create the dataset for mayoral elections
mkdstsmd.prg   Create the dataset for >10,000 settlement SMD elections
mkdstkis.prg   Create the dataset for <10,000 settlement list elections
mkdstcom.prg   Create the dataset for >10,000 settlement compensation lists





====================================================================
FINAL DATASET:
==============

1. ELTYPE: Type of Electoral Body
   1 = mayor
   2 = city (large municipal) SMD
   3 = city (large municipal) compensation list 
   4 = town/village multi-member plurality municipal lists
   5 = county PR lists

2. SETCODE: Settlement/County code
   (missing for mayoral elections)

3. SMDNO: SMD Number

4. METHOD: Electoral Method
   1 = plurality
   2 = Hungarian Sainte-Lague HA
   3 = Standard Sainte-Lague HA
   4 = Modified Saint-Lague HA
   5 = d'Hondt HA
   6 = LR-Hare
   7 = LR-Droop
   8 = LR-Imperiali
   9 = Imperiali HA
   10 = Equal Proportions HA
   11 = Danish HA
   12 = Adams HA
   13 = Mixed SMD/Hun.St-L

5. M: District Magnitude

6. MAXCANDP: Largest candidate/party percentage vote

7. MINCANDP: Smallest candidate/party percentage vote

8. WINSEATP: Winner seat proportion

9. EFFNELEC: Electoral effective number of parties

10. EFFNPARL: Parliament effective number of parties

11. ACTNELEC: Election actual number of parties

12. ACTNPARL: Parliament actual number of parties

13. DISPRLH: Loosemore-Hanby Disproportionality index

14. DISPRLS: Least-squares Disproportionality index

15. DISPRSL: Sainte-Lague disprortionality index

16. AVGCOALP: Average number of parties in coalitions

17. TOTINDEP: Total number of independent candidates

Note that this is for unique parties in the election, not for each
candidate.  Also, independents always count as a single, one-party
coalition.  Example (from loc94kis.asc):

  setcode pcode   votes
  02028   000000  235
  02028   000000  219
  02028   021097  209
  02028   021097  178
  02028   000000  155
  02028   000000  154
  02028   000000  153
  02028   021097  151

computes as:   3 (3 parties in 021097)
             + 5 (5 independents)
            ----
               8
             / 6 (total parties)
            ----
            1.33 Average parties in coalitions

17. TOTINDEP: Total number of independent candidates

18. SETPOP: Settlement population

====================================================================
Checklist:


Mayoral Elections				3,136 finmay.dat

SMDs in Settlements > 10,000			2,063 finsmd.dat

Settlements < 10,000			        2,977 finkis.dat

[recreated] Hung. St-Lague from county lists	   39 
Simulated Sainte-Lague from county lists	   39
Simulated modified Sainte-Lague from county lists  39
Simulated d'Hondt from county lists		   39
Simulated LR-Hare from county lists		   39
Simulated LR-Droop from county lists		   39
Simulated LR-Imperiali from county lists	   39
Simulated Imperiali HA from county lists	   39
Simulated Equal Proportions from county lists	   39
Simulated Danish Method from county lists	   39
Simulated Adams method from county lists	   39
                          total...................429 fincty.dat

[recreated] Hung. St-Lag from settl. comp lists   162 
Simulated Sainte-Lague from settl. comp lists	  162
Simulated modified St-Lag from settl. comp lists  162
Simulated d'Hondt from settl. comp lists	  162
Simulated LR-Hare from settl. comp lists	  162
Simulated LR-Droop from settl. comp lists	  162
Simulated LR-Imperiali from settl. comp lists	  162
Simulated Imperiali HA from settl. comp lists	  162
Simulated Equal Proport. from settl. comp lists	  162
Simulated Danish Method from settl. comp lists	  162
Simulated Adams method from settl. comp lists	  162
                          total.................1,782 fincom.dat


TOTAL..........................................10,387 loc94.dat


Mixed electoral systems from large settlements    162 finmix.dat
(not finished yet)
