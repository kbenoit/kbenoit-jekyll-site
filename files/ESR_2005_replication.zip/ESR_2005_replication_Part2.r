#
# Do bivariate densities from Irish election study
# Kenneth Benoit
# for APSA 2003 paper
#

library(ash)
library(foreign)
library(deldir)


######################################################
### Routines for two-dimensional HDRs and boxplots ###
###         Last updated 16 September 2002         ###
######################################################

den.2d <- function(x,y,a=1,b=1,grid.size=100)
{
    # Computes density estimate of data in (x,y).
    # a and b are smoothing parameters in x and y directions respectively.
    # Any density estimation function can be used provided it
    # returns a list of x, y and z where x and y are grid margins on the sample
    # space spanning at least the range of the data and z is a matrix containing
    # the density estimated at each point on the grid.
 
    require(ash)   
    return(ash2(bin2(cbind(x,y)),5*c(a,b)))
#    junk <- preplot.locfit(locfit(~x+y,alpha=c(a,b)))
#    minx <- min(junk$xev[[1]])
#    maxx <- max(junk$xev[[1]])
#    rx <- (maxx-minx)
#    xx <- seq(minx-0.2*rx,maxx+0.2*rx,l=grid.size)
#    miny <- min(junk$xev[[2]])
#    maxy <- max(junk$xev[[2]])
#    ry <- (maxy-miny)
#    yy <- seq(miny-0.2*ry,maxy+0.2*ry,l=grid.size)
#    oldgrid <- expand.grid(junk$xev[[1]],junk$xev[[2]])
#    zz <- interp(oldgrid[,1],oldgrid[,2],z=junk$fit,xo=xx,yo=yy,extrap=T,ncp=3)$z
#    return(list(x=xx,y=yy,z=matrix(exp(zz),grid.size,grid.size)))
}

#------------------------------------------------------------------------

old.interp.2d <- function(x,y,z,x0,y0)
{
    # Bilinear interpolation of function (x,y,z) onto (x0,y0).
    # Taken from Numerical Recipies (second edition) section 3.6.
    # Slow because of loop.  Would be better in C or Fortran.
    # Called by hdr.info.2d

    n <- length(x)
    n0 <- length(x0)
    z0 <- numeric(length=n0)

    for(i in 1:n0)
    {
        d <- x - x0[i]
        j <- (1:(n-1))[ d[1:(n-1)]*d[2:n] < 0]
        d <- y - y0[i]
        k <- (1:(n-1))[ d[1:(n-1)]*d[2:n] < 0]
        v <- (x0[i] - x[j])/(x[j+1]-x[j])
        u <- (y0[i] - y[k])/(y[k+1]-y[k])
        z0[i] <- (1-v)*(1-u)*z[j,k] + v*(1-u)*z[j+1,k] + v*u*z[j+1,k+1] + (1-v)*u*z[j,k+1]
    }
    return(z0)
}

interp.2d <- function(x, y, z, x0, y0)
{
    # Bilinear interpolation of function (x,y,z) onto (x0,y0).
    # Taken from Numerical Recipies (second edition) section 3.6.
    # Called by hdr.info.2d
    # Vectorized version of old.interp.2d. 
    # Contributed by Mrigesh Kshatriya (mkshatriya@zoology.up.ac.za)

    nx <- length(x)
    ny <- length(y)
    n0 <- length(x0)
    z0 <- numeric(length = n0)
    xr <- diff(range(x))
    yr <- diff(range(y))
    xmin <- min(x)
    ymin <- min(y)
    j <- ceiling(((nx - 1) * (x0 - xmin))/xr)
    k <- ceiling(((ny - 1) * (y0 - ymin))/yr)
    j[j == 0] <- 1
    k[k == 0] <- 1
    j[j == nx] <- nx - 1
    k[k == ny] <- ny - 1
    v <- (x0 - x[j])/(x[j + 1] - x[j])
    u <- (y0 - y[k])/(y[k + 1] - y[k]) 
    AA <- z[cbind(j, k)]
    BB <- z[cbind(j + 1, k)]
    CC <- z[cbind(j + 1, k + 1)]
    DD <- z[cbind(j, k + 1)]
    z0 <- (1 - v) * (1 - u) * AA + v * (1 - u) * BB + v * u * CC + (1 - v) * u * DD
    return(z0)
}

#------------------------------------------------------------------------

hdr.info.2d <- function(x, y, den, alpha)
{
    # Calculates falpha needed to compute HDR of bivariate density den.
    # Also finds approximate mode.
    # Input: den = bivariate density on grid.
    #      (x,y) = indpendent observations on den
    #      alpha = level of HDR
    # Called by plot.hdr.2d

    fxy <- interp.2d(den$x,den$y,den$z,x,y)
    falpha <- quantile(sort(fxy), alpha)
    index <- (fxy==max(fxy))
    mode <- c(x[index],y[index])
    return(list(falpha=falpha,mode=mode,fxy=fxy))
}

#------------------------------------------------------------------------

plot.hdr.2d <- function(x, y, den, alpha=c(0.01,0.05,0.50), shaded=T, show.points=T,
        outside.points=T, pch=19, ...)
{
    # Plots bivariate HDRs
    # Assumes den contains density.
    # Shows mode(s) as 'o'
    # If shaded=T, will plot shaded polygons instead of contours with highest density
    # shading for highest density region.
    # If show.points=T, will plot points over the top of contours or polygons.
    # If show.points=F and outside.points=T, will plot only points outside largest HDR.

    cols <- gray((9:1)/10)
    hdr <- hdr.info.2d(x, y, den, alpha=alpha)
#    if(shaded)
#        filled.contour(den,levels=c(hdr$falpha,1e10),col=cols,key=F,...)
#    else
        contour(den,levels=hdr$falpha,labcex=0,...)
    if(show.points)
        points(x,y,pch=pch)
    else if(outside.points)
    {
        index <- (hdr$fxy < 0.99999*min(hdr$falpha))
        points(x[index], y[index], pch=pch)
    }
    points(hdr$mode[1],hdr$mode[2],pch="o")
    invisible(hdr)
}

#------------------------------------------------------------------------

hdr.boxplot.2d <- function(x, y, a=1, b=1, grid.size=100,show.points=F, xlab="", ylab="", ...)
{
    # Plots bivariate HDRs in form of boxplot.

    den <- den.2d(x,y,a,b,grid.size)
    invisible(plot.hdr.2d(x, y, den, c(0.01,0.50), show.points=F, xlab=xlab, ylab=ylab, ...))
}

#------------------------------------------------------------------------

## Replacement function for filled.contour()
## This version enables the key to be turned off.
## Default behaviour is identical to usual function.

filled.contour <- function (x = seq(0, 1, len = nrow(z)), y = seq(0, 1, len = ncol(z)), 
    z, xlim = range(x, finite = TRUE), ylim = range(y, finite = TRUE), 
    zlim = range(z, finite = TRUE), levels = pretty(zlim, nlevels), 
    nlevels = 20, color.palette = cm.colors, col = color.palette(length(levels) - 
        1), plot.title, plot.axes, key.title, key.axes, asp = NA, 
    xaxs = "i", yaxs = "i", las = 1, axes = TRUE, key=T,...) 
{
    if (missing(z)) {
        if (!missing(x)) {
            if (is.list(x)) {
                z <- x$z
                y <- x$y
                x <- x$x
            }
            else {
                z <- x
                x <- seq(0, 1, len = nrow(z))
            }
        }
        else stop("no `z' matrix specified")
    }
    else if (is.list(x)) {
        y <- x$y
        x <- x$x
    }
    if (any(diff(x) <= 0) || any(diff(y) <= 0)) 
        stop("increasing x and y values expected")
    mar.orig <- (par.orig <- par(c("mar", "las", "mfrow")))$mar
    on.exit(par(par.orig))
    if(key)
    {
        w <- (3 + mar.orig[2]) * par("csi") * 2.54
        layout(matrix(c(2, 1), nc = 2), widths = c(1, lcm(w)))
        par(las = las)
        mar <- mar.orig
        mar[4] <- mar[2]
        mar[2] <- 1
        par(mar = mar)
        plot.new()
        plot.window(xlim = c(0, 1), ylim = range(levels), xaxs = "i", 
            yaxs = "i")
        rect(0, levels[-length(levels)], 1, levels[-1], col = col)
        if (missing(key.axes)) {
            if (axes) 
                axis(4)
        }
        else key.axes
        box()
        if (!missing(key.title)) 
            key.title
    }
    mar <- mar.orig
    mar[4] <- 1
    par(mar = mar)
    plot.new()
    plot.window(xlim, ylim, "", xaxs = xaxs, yaxs = yaxs, asp = asp)
    if (!is.matrix(z) || nrow(z) <= 1 || ncol(z) <= 1) 
        stop("no proper `z' matrix specified")
    if (!is.double(z)) 
        storage.mode(z) <- "double"
    .Internal(filledcontour(as.double(x), as.double(y), z, as.double(levels), 
        col = col))
    if (missing(plot.axes)) {
        if (axes) {
            title(main = "", xlab = "", ylab = "")
            axis(1)
            axis(2)
        }
    }
    else plot.axes
    box()
    if (missing(plot.title)) 
        title(...)
    else plot.title
    invisible()
}


KQ.den.2d <- function(x,y,a=1,b=1,grid.size=100)
{
    # Computes density estimate of data in (x,y).
    # a and b are smoothing parameters in x and y directions respectively.
    # Any density estimation function can be used provided it
    # returns a list of x, y and z where x and y are grid margins on the
    # sample
    # space spanning at least the range of the data and z is a matrix
    # containing
    # the density estimated at each point on the grid.

    require(ash)
    return(ash2(bin2(cbind(x,y),nbin=c(grid.size,grid.size)),5*c(a,b)))
#    junk <- preplot.locfit(locfit(~x+y,alpha=c(a,b)))
#    minx <- min(junk$xev[[1]])
#    maxx <- max(junk$xev[[1]])
#    rx <- (maxx-minx)
#    xx <- seq(minx-0.2*rx,maxx+0.2*rx,l=grid.size)
#    miny <- min(junk$xev[[2]])
#    maxy <- max(junk$xev[[2]])
#    ry <- (maxy-miny)
#    yy <- seq(miny-0.2*ry,maxy+0.2*ry,l=grid.size)
#    oldgrid <- expand.grid(junk$xev[[1]],junk$xev[[2]])
#    zz <-
#interp(oldgrid[,1],oldgrid[,2],z=junk$fit,xo=xx,yo=yy,extrap=T,ncp=3)$z
#    return(list(x=xx,y=yy,z=matrix(exp(zz),grid.size,grid.size)))
}


KQ.plot.hdr.2d <- function(x, y, den, alpha=c(0.01,0.05,0.50),
                           shaded=T, show.points=T,
                           outside.points=T, pch=19, x.points, y.points,
                           labels.points, ...)
{
    # Plots bivariate HDRs
    # Assumes den contains density.
    # Shows mode(s) as 'o'
    # If shaded=T, will plot shaded polygons instead of contours with
    # highest density
    # shading for highest density region.
    # If show.points=T, will plot points over the top of contours or
    # polygons.
    # If show.points=F and outside.points=T, will plot only points outside
    # largest HDR.

    #cols <- gray((9:0)/10)

    ncolor <- length(alpha)
    cols <- gray((ncolor-.5):.5/ncolor)

    hdr <- hdr.info.2d(x, y, den, alpha=alpha)
    if(shaded)
        filled.contour(den,levels=c(hdr$falpha,1e10),col=cols,key=F,
                       plot.axes={axis(1); axis(2);
                                  points(x.points, y.points, pch=16);
                                  points(x.points, y.points, pch=16,
                                         cex=.5, col="white");
                                  identify(x.points, y.points,
				 labels.points)
                                },
                       ...)
    #else
    contour(den,add=TRUE,lwd=1.5,levels=hdr$falpha,drawlabels=F,...)
    deldir(x.points,y.points,lty=2,plot=TRUE,wl='te',wpoints='none',add=TRUE)

    if(show.points)
        points(x,y,pch=pch)
    else if(outside.points)
    {
        index <- (hdr$fxy < 0.99999*min(hdr$falpha))
        points(x[index], y[index], pch=pch)
    }
    #points(hdr$mode[1],hdr$mode[2],pch="o")
    invisible(hdr)
}



parties <- c("FF", "FG", "GR", "Lab", "PDs", "SF")
EUstr   <- c(12.6, 8.3,  16.9, 10.2, 13.2, 16.9)
immig  <- c(14.8, 13.0,  6.1,  6.9, 14.2,  8.9)
econ   <- c(13.7, 12.4,  5.7,  6.5, 17.4,  4.8)
NI     <- c( 6.3, 10.9,  8.7,  9.1, 11.0,  1.5)
social <- c(14.7, 11.3,  5.7,  6.1,  7.0,  9.6)
EUenl  <- c(7.1, 5.3, 9.8, 5.7, 6.7, 12.0)
envt   <- c(15.9, 13.7, 2.4, 9.5, 15.4, 10.1)



### FIGURE 6
### Economic v. Northern Ireland
#
ines <- read.dta("pubprivvNI7.dta", convert.factors=FALSE)
labels.points <- parties
x.points <- econ
y.points <- NI
x <- (1 + (19/30)*(ines$pubpriv))
y <- 21 - ((-13/6) + (19/12)*ines$northirl)
den <- KQ.den.2d(x, y, grid.size=125,a=5, b=5)
KQ.plot.hdr.2d(x, y, den,alpha=c(0.05,0.25,0.5,.75,0.95),
               xlab="Economic Dimension",
               ylab="Northern Ireland Dimension",
 	       shaded=TRUE, show.points=FALSE,
               outside.points=FALSE, 
               x.points=x.points, y.points=y.points, 
               labels.points=labels.points,)


### FIGURE 7
### Economic (public v. private) v. Social
#
ines <- read.dta("pubprivvlibcon7.dta", convert.factors=FALSE)
labels.points <- parties
x.points <- econ
y.points <- social
x <- (1 + (19/30)*(ines$pubpriv))
y <- 1 + (19/20)*ines$libcon
den <- KQ.den.2d(x, y, grid.size=150,a=4.5, b=4.5)
KQ.plot.hdr.2d(x, y, den,alpha=c(0.05,0.25,0.5,.75,0.95),
               xlab="Economic Dimension",
               ylab="Social Dimension",
 	       shaded=TRUE, show.points=FALSE,
               outside.points=FALSE, 
               x.points=x.points, y.points=y.points, 
               labels.points=labels.points)

